package com.baby.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders

class MainActivity : AppCompatActivity() {
    private lateinit var mainViewModel:viewmodel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(viewmodel::class.java)
    }
}

class viewmodel : ViewModel(){
    private var name = ""

    fun setname(newName:String){
        name = newName
    }

    fun getName() = name
}